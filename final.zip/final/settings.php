<?php
	$host = "feenix-mariadb.swin.edu.au";
	$user = "s102868394"; // your user name
	$pwd = "A1varado!!"; // your password (date of birth ddmmyy unless changed)
	$sql_db = "s102868394_db"; // your database
?>

	
