<!-- manager page to query candidates from registration database -->
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="description" content="Manage seminar registrations" />
  <meta name="keywords" content="seminars, tastings, awesome, manage" />
  <meta name="author" content="Sergio Alvarado"  />
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>Renown Seminars</title>
  <link rel="stylesheet" href="styles/style.css">
  <link rel="stylesheet" href="styles/webfontkit/stylesheet.css">
</head>
<body>
  <?php include "header.inc"; ?>
  <?php include "menu.inc"; ?>
  <div class="centered">
    <form class="inline" action="manager.php" method="post">
      <input type="submit" class="button" value="All registers">
    </form>
    <form class="inline" action="manager.php" method="post">
      <label class="bold black" for="search">Search:</label>
      <input id="search" type="text" name="username" placeholder="Search username">
      <input type="submit" class="button" value="Search">
    </form>
    <form class="inline" action="manager.php" method="post">
      <label class="bold black">List:</label>
      <input type="radio" name="list" value="Organiser" id="org"> <label for="org" class="black">Organisers</label>
      <input type="radio" name="list" value="Participant" id="part"> <label for="part" class="black">Participants</label>
      <input type="submit" class="button" value="List">
    </form>
  </div>
  <br>
  <br>
  <?php
    require_once "settings.php";
    $conn = @mysqli_connect($host,$user,$pwd,$sql_db);
    if($conn) {
      if (isset($_POST["username"])) {
         if ($_POST["username"]!=""){
           $query = "select * from registration where username='$_POST[username]'";
         }else {
           $query = "select * from registration";
         }
      }else if (isset($_POST["list"])) {
        $query = "select * from registration where role='$_POST[list]' order by username desc";
      }else {
        $query = "select * from registration";
      }
      $result = @mysqli_query($conn, $query);
      echo "<table class='center'>\n";
      echo "<tr><th>ID</th><th>Username</th><th>Seminar Number</th><th>Qualification</th><th>Email</th><th>Phone</th><th>Role</th></tr>\n";
      $row = mysqli_fetch_row($result);
      while ($row){
        echo "<tr><td>{$row[0]}</td>\n";
        echo "<td>{$row[2]}</td>\n";
        echo "<td>{$row[1]}</td>\n";
        echo "<td>{$row[3]}</td>\n";
        echo "<td>{$row[4]}</td>\n";
        echo "<td>{$row[5]}</td>\n";
        echo "<td>{$row[6]}</td></tr>\n";
        $row = mysqli_fetch_row($result);
      }
      echo "</table>\n";
      mysqli_close($conn);
    }
    else
      echo"<h5>Unable to connect to the db.</h5>";
  ?>
  <?php include "footer.inc"; ?>

</body>
</html>
