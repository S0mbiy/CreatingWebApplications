<!-- process page to register candidates into registration database -->
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="description" content="Registered into one of our seminars" />
  <meta name="keywords" content="seminars, tastings, awesome, register" />
  <meta name="author" content="Sergio Alvarado"  />
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>Renown Seminars</title>
  <link rel="stylesheet" href="styles/style.css">
  <link rel="stylesheet" href="styles/webfontkit/stylesheet.css">
</head>
<body>
  <?php include "header.inc"; ?>
  <?php include "menu.inc"; ?>
  <?php
    require_once "settings.php";
    $conn = @mysqli_connect($host,$user,$pwd,$sql_db);
    if($conn) {
      $query = "CREATE TABLE registration (
ID int(11) NOT NULL AUTO_INCREMENT,
seminar_num varchar(6) NOT NULL,
username varchar(20) NOT NULL,
qualification varchar(13) NOT NULL,
email varchar(50) NOT NULL,
phone varchar(10) NOT NULL,
role varchar(11) NOT NULL,
PRIMARY KEY (ID)
) ENGINE=InnoDB DEFAULT CHARSET=latin1";
      $result = @mysqli_query($conn, $query);
      if (!isset($_POST["qualification"])) {
        echo "<h5>Please select your qualification.</h5>";
      }else {
        if ($_POST["qualification"]=='Undergraduate' && $_POST["role"]=="Organiser"){
          echo "<h5>Undergraduates cannot be registered as organisers.</h5>";
        }else {
          $insert_pro = $conn->prepare("insert into registration (seminar_num, username, qualification, email, phone, role) values (?, ?, ?, ?, ?, ?)");
          $insert_pro->bind_param("ssssss", $_POST['ref'], $_POST['user'], $_POST['qualification'], $_POST['email'], $_POST['phone'], $_POST['role']);
          $result = $insert_pro->execute();
          if ($result) {
            echo "<h5>You are successfully registered!</h5>";
          } else {
            echo "<h5>",mysqli_error($conn),"</h5>";
          }
        }
      }
      mysqli_close($conn);
    }
    else
      echo"<h5>Unable to connect to the db.</h5>";
  ?>
  <?php include "footer.inc"; ?>

</body>
</html>
