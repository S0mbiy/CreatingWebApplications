<!-- main page of the seminar company -->
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="description" content="Aquire the taste of the elite" />
  <meta name="keywords" content="seminars, tastings, awesome" />
  <meta name="author" content="Sergio Alvarado"  />
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>Renown Seminars</title>
  <link rel="stylesheet" href="styles/style.css">
  <link rel="stylesheet" href="styles/webfontkit/stylesheet.css">
  <script src="scripts/apply.js"></script>
</head>
<body>
  <?php include "header.inc"; ?>
  <?php include "menu.inc"; ?>
  <article>

    <section>
      <h1>Wine tasting seminar</h1>
      <p>Join us in a gastronomical trip trough the most renown vineyards of
        Italy without leaving Melbourne by joinning our 2 week seminar on wine tasting. <br>
        Learn the differents between multiple types of grapes, train your taste to
        differentiate between wine notes, and get ready to impress everyone with your wine knowledge.
      </p>
      <h3>Reference Number: S00001</h3>
      <a href="register.php" id="apply1">Apply Now</a>
      <figure>
        <img src="img/wine.jpg" alt="wine">
        <figcaption>Image from: https://www.theiwsr.com/news-and-comment-global-still-wine-trends-to-watch/</figcaption>
      </figure>

    </section>

    <section>
      <h1>Cheese tasting seminar</h1>
      <p>Join us in a gastronomical trip trough the most renown chees factories of
        France without leaving Melbourne by joinning our 2 week seminar on cheese tasting. <br>
        Learn the differents between multiple types of cheese, train your taste to
        differentiate between aged and regular cheese, and get ready to impress everyone with your cheese knowledge.
      </p>
      <h3>Reference Number: S00002</h3>
      <a href="register.php" id="apply2">Apply Now</a>
      <figure>
        <img src="img/cheese.jpg" alt="cheese">
        <figcaption>Image from: https://www.healthline.com/nutrition/healthiest-cheese#section7</figcaption>
      </figure>
    </section>

  </article>
  <?php include "footer.inc"; ?>
</body>
</html>
