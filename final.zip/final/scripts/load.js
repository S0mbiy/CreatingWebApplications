/**
* Author: Sergio Alvarado
* Target: index.php
* Purpose: pass seminar reference number
* Credits: Grace Tao
*/
"use strict";

function init(){
  var ref = document.getElementById("ref").value = sessionStorage.getItem('seminar');;

}

window.onload=init;
