/**
* Author: Sergio Alvarado
* Target: index.php
* Purpose: pass seminar reference number
* Credits: Grace Tao
*/
"use strict";

function a1(){
  sessionStorage.setItem('seminar', 'S00001');
}

function a2(){
  sessionStorage.setItem('seminar', 'S00002');
}

function init(){
  var apply1 = document.getElementById("apply1");
  var apply2 = document.getElementById("apply2");
  apply1.onclick = a1;
  apply2.onclick = a2;
}

window.onload=init;
