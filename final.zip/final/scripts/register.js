/**
* Author: Sergio Alvarado
* Target: register.php
* Purpose: validate form fields
* Credits: Grace Tao
*/
"use strict";

function validate(){
  var error = "";
  var ref = document.getElementById("ref").value;
  if (!ref.match(/^S[0-9]{5}$/)) {
    error += "Seminar reference number must start with capital S followed by 5 digits.\n"
  }

  var user = document.getElementById("user").value;
  if (!user.match(/^[a-zA-Z]{2,20}$/)) {
    error += "Username must be between 2 and 20 alpha characters only.\n"
  }

  var phone = document.getElementById("phone").value;
  if (!phone.match(/^[0-9]{10}$/)) {
    error += "Phone number must be 10 digits long.\n"
  }

  if(error != ""){
    alert(error);
    return false;
  }
  return true;
}

function init(){
  var form = document.getElementById("form");
  form.onsubmit = validate;
}

window.onload=init;
