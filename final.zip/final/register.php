<!-- register page to register into a seminar -->
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="description" content="Register into one of our seminars" />
  <meta name="keywords" content="seminars, tastings, awesome, register" />
  <meta name="author" content="Sergio Alvarado"  />
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>Renown Seminars</title>
  <link rel="stylesheet" href="styles/style.css">
  <link rel="stylesheet" href="styles/webfontkit/stylesheet.css">
  <script src="scripts/register.js"></script>
  <script src="scripts/load.js"></script>
</head>
<body>
  <?php include "header.inc"; ?>
  <?php include "menu.inc"; ?>

  <article>
    <h1>Register Form:</h1>
    <form id="form" action="process.php" method="post" novalidate>
      <p>
        <label for="ref">Seminar reference number:</label>
        <input type="text" name="ref" id="ref" required>
      </p>
      <p>
        <label for="ref">Username:</label>
        <input type="text" name="user" id="user" required>
      </p>
      <p>
        <label class="bold">Qualification:</label>
        <input type="radio" name="qualification" value="Undergraduate" id="under"> <label for="under">Undergraduate</label>
        <input type="radio" name="qualification" value="Postgraduate" id="post"> <label for="post">Postgraduate</label>
      </p>
      <p>
        <label for="email">Email address:</label>
        <input type="email" name="email" id="email" required>
      </p>
      <p>
        <label for="phone">Phone number:</label>
        <input type="text" name="phone" id="phone" required>
      </p>
      <p>
        <label>Role:</label>
        <select name="role" required>
          <option value="">Select...</option>
          <option value="Organiser">Organiser</option>
          <option value="Participant">Participant</option>
        </select>
      </p>
      <input type="submit" class="button" value="Register">

    </form>
  </article>
  <?php include "footer.inc"; ?>

</body>
</html>
